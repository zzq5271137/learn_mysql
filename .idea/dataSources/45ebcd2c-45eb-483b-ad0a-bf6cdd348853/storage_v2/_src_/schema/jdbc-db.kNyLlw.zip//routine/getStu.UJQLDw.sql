create
    definer = root@localhost procedure getStu(IN n varchar(50))
BEGIN
	SELECT * FROM student where name = n;
END;

